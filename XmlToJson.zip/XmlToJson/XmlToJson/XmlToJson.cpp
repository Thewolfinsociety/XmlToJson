﻿// XmlToJson.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "pch.h"
#include <iostream>
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <vector>
#include "../tinyxml/tinyxml.h"
#include "../ClassPackage/PackageClass.h"

#include<vector>
#include<algorithm>

using namespace std;

void addChile(TiXmlElement * parent, const char* node, int value);
void addChile(TiXmlElement * parent, const char* node, const char* value);
class Bom
{
public:
	int value_lsk, value_rsk, value_zk, value_zs, value_ls, value_lg, value_ltm, value_rtm;

	double length;   // 长度
	double breadth;  // 宽度
	double height;   // 高度
	int XmlToJson(const char* xmlfile);
	int ImportXomItemForBom(BomParam *param0, int & id, int &slino);
	void SetSysVariantValue(const char* vname, const char* value);
};
void Bom::SetSysVariantValue(const char* vname, const char* value)
{
	if (strcmp(vname, "$左收口宽度") == 0)
		value_lsk = atoi(value);

	if(strcmp(vname, "$右收口宽度") == 0)
		value_rsk = atoi(value);
	if(strcmp(vname, "$柱切角宽度") == 0)
		value_zk = atoi(value);
	if(strcmp(vname, "$柱切角深度") == 0)
		value_zs = atoi(value);
	if(strcmp(vname, "$梁切角深度") == 0)
		value_ls = atoi(value);
	if(strcmp(vname, "$梁切角高度") == 0)
		value_lg = atoi(value);
	if(strcmp(vname, "$左侧趟门位") == 0)
		value_ltm = atoi(value);
	if(strcmp(vname, "$右侧趟门位") == 0)
		value_rtm = atoi(value);
}
struct Node
{
	int id;
	char when[32];
	char who[32];
	char where[32];
};
vector<Node> nodes;
vector<Node> Node_read;
//想容器添加东西
void addNode(int id, const char* when, const char* who, const char* where)
{
	Node n;
	n.id = id;																																																																										strcpy_s(n.when, when);
	strcpy_s(n.who, who);
	strcpy_s(n.where, where);
	nodes.push_back(n);
}
//保存到xml文件中
int save()
{
	TiXmlDocument xml_doc;
	//添加声明
	xml_doc.LinkEndChild(new TiXmlDeclaration("1.0", "GBK", ""));
	//添加根元素
	TiXmlElement* xml_root = new TiXmlElement("root");
	xml_doc.LinkEndChild(xml_root);
	//根元素下面添加节点
	for (unsigned int i = 0; i < nodes.size(); i++)
	{
		Node& n = nodes[i];
		//创建一个节点
		TiXmlElement* xml_node = new TiXmlElement("node");
		xml_root->LinkEndChild(xml_node);
		//创建第一个子节点
		if (1)
		{
			addChile(xml_node, "id", n.id);
			addChile(xml_node, "when", n.when);
			addChile(xml_node, "where", n.where);
			addChile(xml_node, "who", n.who);
		}
	}
	//保存文件
	xml_doc.SaveFile("aaaa.xml");
	return 0;
}
//添加子节点
void addChile(TiXmlElement * parent, const char* node, int value)
{
	//创建节点
	TiXmlElement* xml_node = new TiXmlElement(node);
	//将int转为char
	char buf[32];
	sprintf_s(buf, "%d", value);
	xml_node->LinkEndChild(new TiXmlText(buf));
	parent->LinkEndChild(xml_node);

}

void addChile(TiXmlElement * parent, const char* node, const char* value)
{
	//创建节点
	TiXmlElement* xml_node = new TiXmlElement(node);
	//将int转为char
	xml_node->LinkEndChild(new TiXmlText(value));
	parent->LinkEndChild(xml_node);
}
//生成xml文件
int test1()
{
	TiXmlDocument xml_doc;
	//添加XML声明
	xml_doc.LinkEndChild(new TiXmlDeclaration("1,0", "GBK", ""));
	//添加根元素
	TiXmlElement* xml_root = new TiXmlElement("root");
	xml_doc.LinkEndChild(xml_root);
	//在根元素添加其他子元素
	if (1)
	{
		//添加host
		TiXmlElement* xml_child = new TiXmlElement("host");
		xml_root->LinkEndChild(xml_child);
		//添加文档内容
		xml_child->LinkEndChild(new TiXmlText("127.0.0.1"));
		//设置属性
		xml_child->SetAttribute("checked", "true");
		xml_child->SetAttribute("station", 1001);
	}
	//嵌套子元素
	if (1)
	{
		TiXmlElement* xml_client = new TiXmlElement("client");
		xml_root->LinkEndChild(xml_client);

		TiXmlElement* xml_clientName = new TiXmlElement("name");
		xml_clientName->LinkEndChild(new TiXmlText("andy"));
		xml_client->LinkEndChild(xml_clientName);

		TiXmlElement* xml_clientId = new TiXmlElement("id");
		xml_clientId->LinkEndChild(new TiXmlText("20190608"));
		xml_client->LinkEndChild(xml_clientId);

		//保存文件
		xml_doc.SaveFile("example.xml");
		//或者转成string
		string text;
		//text << xml_doc;
		return 0;
	}
}

//解析xml文件
int test2()
{
	//解析xml
	TiXmlDocument xml_doc;
	if (!xml_doc.LoadFile("example.xml"))
	{
		return -1;
	}
	//根节点
	TiXmlElement* xml_root = xml_doc.RootElement();
	if (xml_root == NULL)
	{
		return -1;
	}
	//获取元素的文本与属性
	if (1)
	{
		TiXmlElement* xml_host = xml_root->FirstChildElement("host");
		const char* text = xml_host->GetText();
		const char* aCheckedd = xml_host->Attribute("checked");
		const char* aStation = xml_host->Attribute("station");
		printf("text:%s , checked:%s , station:%s", text, aCheckedd, aStation);
	}
	if (1)
	{
		TiXmlElement* xml_client = xml_root->FirstChildElement("client");

		TiXmlElement* xml_name = xml_client->FirstChildElement("name");
		TiXmlElement* xml_id = xml_client->FirstChildElement("id");
	}
	return 0;
}
void MyVariant(string str, string & s1, string & s2)
{
	s1 = "";
	s2 = "";
	string ws = str;
	int n = 0;
	if (n = ws.find(":") != string::npos)
	{
		s2 = ws.substr(n+2);
		s1 = ws.substr(0, n+1);
	}
	
	
}

int Bom::ImportXomItemForBom(BomParam *param0, int &id, int &slino)
{
	int Result = 0;
	string ls = "";
	TExpress exp;
	exp.AddVariable("L", "", to_string(param0->pl), "", "");
	exp.AddVariable("P", "", to_string(param0->pd), "", "");
	exp.AddVariable("H", "", to_string(param0->ph), "", "");
	exp.AddVariable("BH", "", to_string(param0->boardheight),"", "");
	exp.mBHValue = param0->boardheight;
	printf("%d", param0->boardheight);
	param0->blockmemo = "";
	bool isdoor = false;
	TiXmlElement *root = param0->rootnode;

	const char* str = root->Attribute("模块备注");
	if (str != NULL)
	{
		param0->blockmemo = str;
		printf("blockmemo=%s", param0->blockmemo.c_str());
		param0->blockmemo = StringReplace(param0->blockmemo, "[宽]", to_string(param0->pl));
		param0->blockmemo = StringReplace(param0->blockmemo, "[深]", to_string(param0->pd));
		param0->blockmemo = StringReplace(param0->blockmemo,"[高]", to_string(param0->ph));
	}
	str = root->Attribute("类别");
	if ((strcmp(str, "趟门,趟门") == 0) or (strcmp(str, "趟门,趟门") == 0)) 
	{
		TiXmlElement* node = root->FirstChildElement("模板");
		if (node != NULL)
		{
			//string childxml = "";
			TiXmlText* childxml = node->ToText();
		}
	}
	TiXmlElement* node = root->FirstChildElement();
	//if (node != NULL)
	//{
	//	//string childxml = "";
	//	TiXmlText* childxml = node->ToText();
	cout << root->FirstChild()->Value() << endl;
		
	for (; node != NULL; node = node->NextSiblingElement())
	{
		str = node->Value();
		cout << str << endl;
		if (strcmp(str, "变量列表") == 0)
		{
			TiXmlElement* cnode = node->FirstChildElement();
			for (; cnode != NULL; cnode = cnode->NextSiblingElement())
			{
				const char* vname = cnode->Attribute("名称");
				const char* value = cnode->Attribute("值");
				SetSysVariantValue(vname, value);
				exp.AddVariable(vname, "", value, "", "");
			}

		}
		else if (strcmp(str, "变量列表") == 0)
		{
			TiXmlElement* cnode = node->FirstChildElement();
			for (; cnode != NULL; cnode = cnode->NextSiblingElement())
			{
				const char* vname = cnode->Attribute("名称");
				const char* value = cnode->Attribute("值");
				SetSysVariantValue(vname, value);
				exp.AddVariable(vname,"", value, "", "");
			}
			
		}
		else if (strcmp(str, "我的模块") == 0)
		{
			cout << "hah" << endl;
		}
		else continue;
	}
	return Result;
}

int Bom::XmlToJson(const char* xmlfile)
{
	//解析xml
	int id = 1;
	int slino = 1;
	TiXmlDocument xml_doc;
	if (!xml_doc.LoadFile(xmlfile))
	{
		return -1;
	}
	//根节点
	TiXmlElement* xml_root = xml_doc.RootElement(); //根节点 产品
	if (xml_root == NULL)
	{
		return -1;
	}
	else 
	{
		const char* nodename = xml_root->Value();
		printf("nodename:%s \n ", nodename);
		int cid = 0;
		
		vector<MyProduct> mProductList;
		TiXmlElement* xml_note = xml_root->FirstChildElement("产品");
		MyProduct productnode;
		if (xml_note != NULL)
		{
			const char* attri = xml_note->Attribute("板材厚度");
			if (attri != NULL) productnode.bh = atoi(attri);
			else productnode.bh = 18;
			const char* extra = xml_note->Attribute("Extra");
			if (extra != NULL) strcpy_s(productnode.extra, extra);
			else strcpy_s(productnode.extra, "");
		}
		
		//获取他们的值
		const char* ID = xml_root->Attribute("ID");
		productnode.id = atoi(ID);
		printf("id:%d \n ", productnode.id);
		const char* name = xml_root->Attribute("名称");
		strcpy_s(productnode.name, name);
		strcpy_s(productnode.gno, name);
		const char* IDSTR = xml_root->Attribute("IDSTR");
		strcpy_s(productnode.IDSTR, IDSTR);

		const char* DBID = xml_root->Attribute("DBID");
		strcpy_s(productnode.DBID, DBID);
		printf("DBID:%s \n ", productnode.DBID);
		const char* des = xml_root->Attribute("描述");
		strcpy_s(productnode.des, des);
	
		const char* gcb = xml_root->Attribute("CB");
		strcpy_s(productnode.gcb, gcb);

		const char* l = xml_root->Attribute("宽");
		productnode.l = atoi(l);

		const char* d = xml_root->Attribute("深");
		productnode.d = atoi(d);

		const char* h = xml_root->Attribute("高");
		productnode.h = atoi(h);

		const char* mat = xml_root->Attribute("材料");
		strcpy_s(productnode.mat, mat);

		const char* color = xml_root->Attribute("颜色");
		strcpy_s(productnode.color, color);

		const char* attri = xml_root->Attribute("基础图形");
		if (attri != NULL) string mBG = attri;
		const char* SpaceFlag = xml_root->Attribute("SpaceFlag");
		string mVName[16];
		string mVValue[16];
		int mC[16];
		for (int j = 0; j <= 15; j++)
		{
			mVName[j] = "";
			mVValue[j] = "";
			mC[j] = 0;
			attri = xml_root->Attribute("参数");
			if (attri != NULL) MyVariant(attri, mVName[j], mVValue[j]);
			mC[j] = atoi(mVValue[j].c_str());
		}
		cid = cid + 1;
		
		mProductList.push_back(productnode);
		//BomParam *param;
		BomParam *param1, param;
		param1 = &param;
		vector<BomOrderItem> bomlist;
		param.productid = mProductList.size();
		param.cid = cid - 1;
		param.boardheight = productnode.bh;
		param.blist = bomlist;
		param.gno = name;
		param.gdes = des;
		param.gcb = gcb;
		param.extra = productnode.extra;
		param.pname = "";
		param.subspace = "";
		param.sozflag = "";
		param.xml = "";
		param.textureclass = "";
		param.pmat = mat;
		param.pcolor = color;
		param.pid = -1;
		param.pl = productnode.l;
		param.pd = productnode.d;
		param.ph = productnode.h;
		param.px = 0;
		param.py = 0;
		param.pz = 0;
		param.space_x = 0;
		param.space_y = 0;
		param.space_z = 0;
		//if spaceflag = '1' then param.space_id = 0 else param.space_id = -1;
		param.outputtype = "";
		param.num = 1;
		param.parent = NULL;
		param.blockmemo = "";
		param.number_text = "";
		param.rootnode = xml_note;
		param.xdoc = xml_doc;
		//param->productid = mProductList.size();
		//param->cid = cid - 1;
		//param->boardheight = productnode.bh;
		//param->blist = bomlist;
		//param->gno = name;
		//param->gdes = des;
		//param->gcb = gcb;
		//param->extra = productnode.extra;
		//param->pname = "";
		//param->subspace = "";
		//param->sozflag = "";
		//param->xml = xml_root->ToText()->Value();
		//param->textureclass = "";
		//param->pmat = mat;
		//param->pcolor = color;
		//param->pid = -1;
		//param->pl = productnode.l;
		//param->pd = productnode.d;
		//param->ph = productnode.h;
		//param->px = 0;
		//param->py = 0;
		//param->pz = 0;
		//param->space_x = 0;
		//param->space_y = 0;
		//param->space_z = 0;
		////if spaceflag = '1' then param->space_id = 0 else param->space_id = -1;
		//param->outputtype = "";
		//param->num = 1;
		//param->parent = NULL;
		//param->blockmemo = "";
		//param->number_text = "";
		//param->rootnode = xml_note;
		//param->xdoc = xml_doc;
		ImportXomItemForBom(param1, id, slino);

	}
	
	//while (xml_note)
	//{
		
	//}
}
//解析多个子节点

int test3()
{
	//开始解析
	TiXmlDocument xml_doc;
	if (!xml_doc.LoadFile("aaaa.xml"))
	{
		return -1;
	}
	//获取根元素
	TiXmlElement* xml_root = xml_doc.RootElement();
	if (xml_root == NULL)
	{
		return -1;
	}
	TiXmlElement* xml_note = xml_root->FirstChildElement("node");
	while (xml_note)
	{
		Node n;
		//获取他们的值
		TiXmlElement* xml_id = xml_note->FirstChildElement("id");
		const char* id = xml_id->GetText();
		n.id = atoi(id);
		TiXmlElement* xml_when = xml_note->FirstChildElement("when");
		strcpy_s(n.when, xml_when->GetText());
		TiXmlElement* xml_where = xml_note->FirstChildElement("where");
		strcpy_s(n.where, xml_where->GetText());
		TiXmlElement* xml_who = xml_note->FirstChildElement("who");
		strcpy_s(n.who, xml_who->GetText());
		Node_read.push_back(n);
		//只想下一个兄弟节点
		xml_note = xml_note->NextSiblingElement();
	}

}

string GetProgramDir();

string GetProgramDir()
{
	wchar_t exeFullPath[MAX_PATH]; // Full path   

	string strPath = "";

	GetModuleFileName(NULL, exeFullPath, MAX_PATH);

	char CharString[MAX_PATH];

	size_t convertedChars = 0;

	wcstombs_s(&convertedChars, CharString, MAX_PATH, exeFullPath, _TRUNCATE);

	strPath = (string)CharString;    // Get full path of the file   

	int pos = strPath.find_last_of('\\', strPath.length());

	return strPath.substr(0, pos);  // Return the directory without the file name   

}

int main()
{
	//test1();
	//addNode(1, "2016-1-23 10:00", "Wang", "吃饭");
	//addNode(2, "2016-1-21 20:00", "Jiang", "看电影");
	//addNode(3, "2016-1-20 9:00", "Li", "去博物馆");
	//save();
	const char *xmlfile;
	
	string base_dir = GetProgramDir();
    xmlfile= "E:\\MicrosoftProject\\C++Project\\XmlToJson\\XmlToJson\\xml\\test.xml"; 
	//printf("base_dir:%s \n", base_dir);
	Bom TBomAndQuoForm;
	int flag = TBomAndQuoForm.XmlToJson(xmlfile);
    cout << "flag=" << flag << endl;
	//int flag = test2();
	//
	////遍历vector
	//for (int i = 0; i < Node_read.size(); i++)   //节点
	//{
	//	Node n = Node_read[i];
	//	printf("id:%d \n, when:%s \n , where:%s \n, who:%s\n", n.id, n.when, n.where, n.who);
	//}
	//printf("保存成功！\n");
	return 0;
}

//int main()
//{
//    std::cout << "Hello World!\n"; 
//	Bom bom;
//	bom.length = 10;
//	cout << "length=" << bom.length;
//
//}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门提示: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
