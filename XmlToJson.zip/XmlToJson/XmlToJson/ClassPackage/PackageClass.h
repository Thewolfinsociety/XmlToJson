#pragma once
#include <string>
#include <Windows.h>
#include <iostream>
using namespace std;
struct MyProduct
{
	int id;
	char name[32];
	char gno[32];
	char IDSTR[255];
	char DBID[255];
	char des[32];
	char gcb[32];
	int l;
	int d;
	int h;
	int bh;
	char color[32];
	char mat[32];
	char extra[255];
};

struct BomOrderItem
{
	int cid;
	string code;
	string name, mat, mat2, mat3, color, workflow;
	int pl, pd, ph, space_x, space_y, space_z, space_id, gcl, gcd, gch, gcl2, gcd2, gch2;  //gcl, gcd, gchͼ�γ�Ʒ����ֵ
    string tmp_soz;
	int lx, ly, lz, x, y, z, l, p, h, gl, gp, gh, holeflag, linemax, holetype;
	float ox, oy, oz;
    int childnum;
	string desc, bomdes, bomwjdes, bomstddes, childbom, myclass, nodename, linecalc, bomstd, bg;
	int direct, lgflag, holeid, kcid;
    int num;
	double lfb, llk, wfb, wlk, llfb, rrfb, ddfb, uufb, fb;
	string memo, gno, gdes, gcb, extra, fbstr, subspace, process, ls, myunit, bomtype, bdxmlid, user_fbstr;
	double bl, bp, bh;                 //���ϳߴ�
    string var_names[16];
    int var_args[16];
	//$���տڿ��ȣ� $���տڿ��ȣ� $���нǿ��ȣ� $���н���ȣ� $���н���ȣ� $���нǸ߶ȣ� $�������λ�� $�Ҳ�����λ
	int value_lsk, value_rsk, value_zk, value_zs, value_ls, value_lg, value_ltm, value_rtm;
	string a_hole_info, b_hole_info, holeinfo;
	bool isoutput, is_outline;
    string outputtype, holeconfig_flag, kcconig_flag, bg_data, mBGParam;

	string bg_filename, mpr_filename, bpp_filename, devcode;
	int zero_y, direct_calctype, youge_holecalc; //zero_y��߿���
	int is_output_bgdata, is_output_mpr, is_output_bpp;

	//����ͼ������
	int bg_l_minx, bg_l_maxx, bg_r_minx, bg_r_maxx, bg_l_miny, bg_l_maxy, bg_r_miny, bg_r_maxy;
	int bg_d_minx, bg_d_maxx, bg_u_minx, bg_u_maxx, bg_d_miny, bg_d_maxy, bg_u_miny, bg_u_maxy;
	int bg_b_minx, bg_b_maxx, bg_f_minx, bg_f_maxx, bg_b_miny, bg_b_maxy, bg_f_miny, bg_f_maxy;

	int hole_back_cap;
    int hole_2_dist; //��һ���׿����ľ��룬���׼��

    bool trans_ab;                  //AB�淴ת
    int ahole_index[101];
    int bhole_index[101];

    int akc_index[101];
    int bkc_index[101];

    int is_calc_holeconfig[6];

    void *parent;
    float floatbasewj_price;
	string extend;
	string group;
    string packno;
    void * userdata ;
    string userdefine;                 //XML�Զ�������
    //ERP����
    string erpunit;
	string erpmatcode;
	string blockmemo;
    string number_text;
}bomOrderItem;

struct BomParam
{
	int productid, cid, boardheight;
	vector<BomOrderItem> blist;
	
    string xml;
	string gno, gdes, gcb, extra, pname, subspace, sozflag, textureclass, pmat, pcolor, group;
	int pid, pl, pd, ph;
	int px, py, pz, space_x, space_y, space_z, space_id;
    string outputtype;
	string blockmemo, number_text;
	int num, mark;
	TiXmlElement* rootnode;
	TiXmlDocument xdoc;
    void *parent;
};

struct mysymbol
{
	string var1;
	string var2;
	string value;
	string value2;
	int flag, used;
};

struct myvariable
{
	string name, alias, value, opvalue, extra;
	int mytype, remove;
    bool change;
};

class TExpress
{
private:
	string mSubject;
    int mDotNum;
	vector <mysymbol> mSblList;
 
	bool mIsSimple, mIsChangeVar;
    string mResult;

	bool IsNumeric(string s);
	int RemovemBrackets(int start, string s, bool neg);
	void SimpleParse(string str);
	void Parse(string str);
	float MyStrToFloat(string str);
	int MyStrToInt(string str, int v);
	string ToSimple(bool isfloat);
	string ToSimpleExpress2(bool isfloat);
	int CalcValue(string str, string &ostr, float &ovalue, float &single, bool isfloat);
	void GetVariantValueSign(string str, mysymbol *p);
	string Symbol2Exp(mysymbol *p);
	void ComSymbolList();
public:
	vector <myvariable> mVarList;

    int mBHValue;                  //��Ӧ-10001

	TExpress();
	~TExpress();

	void SetSubject(string str, bool recalc = false);
	string ToSimpleExpress();
	string ToSimpleExpress(string str);
	string ToValueString;
	int ToValueInt;
	float ToValueFloat;
	void ClearSblList();
	void ClearVarList();
	void ClearSomeVarList();
	void AddVariable(string name, string alias, string value, string opvalue, string extra, int mt = 1);
	void RemoveVariable(string name);
	void UpdateVariable(string name, string value);
	void UpdateVariableByAlias(string name, string value);
	bool IsVariableExists(string name);
	void Clone(TExpress exp);
	void Exchange(TExpress exp);
	void RemoveUnusedVariant(string str);
	void AddVariantFrom(string str);
	bool IsVariableIn(int n, string str);
	void SetVarChangeFlag(bool b);
	vector <mysymbol> GetSymbolList();
	bool IsChangeByVariable(string vname, string value, string str);
	string GetVariableValue(string vname);
	string GetAliasValue(string alias);
	string GetVarAlias(string vname);
	void UpdateVarByVarstr(string vstr, bool is_update_alias= false); //��Alias��ʱ���Ƿ���±���

	float SimpleExpressToValue(string str,int mode); //mode=1 floatģʽ��mode=2 Trunc Intģʽ, mode=3 Round Intģʽ
	int PositiveOrNegative(string exp, string vname);
	
};
bool IsSystemVarName(string name);
string SpecialStringToValue(string str);
string SpecialValueToString(string str);
bool IsSystemVarName(string name)
{
	bool Result = false;
	if ((strcmp(name.c_str(), ("L")) == 0) or (strcmp(name.c_str(), "P") == 0) or (strcmp(name.c_str(), "H") == 0) or (strcmp(name.c_str(), "BH") == 0))
		Result = true;
	return Result;
}
string SpecialStringToValue(string str)
{
	string Result = "";
	if (strcmp(str.c_str(), "���")==0)  Result = "-10001";
	if (str == "") Result = "0";
	return Result;
}
string SpecialValueToString(string str)
{
    string Result = str;
	if (strcmp(str.c_str(), "���")==0) Result = "BH";
	if (strcmp(str.c_str(), "-10001")) Result = "BH";
	if (strcmp(str.c_str(), "")) Result = "0";
	return Result;
}
void TExpress::AddVariable(string name, string alias, string value, string opvalue, string extra, int mt)
{
	int i = 0;
	myvariable *p;
	bool mIsChangeVar = true;
	for (i = 0; i < mVarList.size(); i++)
	{
		p = &mVarList[i];
		if (strcmp(p->name.c_str(), name.c_str()) == 0)
		{
			p->value = value;
			p->mytype = mt;
			p->opvalue = opvalue;
			p->extra = extra;
			p->remove = 0;
			return;
		}
	}
	p = new myvariable();
	p->alias = alias;
	p->name = name;
	p->value = value;
	p->mytype = mt;
	p->opvalue = opvalue;
	p->extra= extra;
	p->remove = 0;
	mVarList.push_back(*p);
}

void TExpress::ClearSblList()
{
	int i = 0;
	mysymbol *p;
	for (i = 0; i < mSblList.size(); i++)
	{
		p = &mSblList[i];
		p->var1 = "";
		p->var2 = "";
		p->value = "";
		p->value2 = "";
	}

	mSblList.clear();
    mIsChangeVar = true;
}

void TExpress::ClearVarList()
{
	int i = 0;
	myvariable *p;
	for (i = 0; i < mVarList.size(); i++)
	{
		p = &mVarList[i];
		p->name = "";
		p->alias = "";
		p->value = "";
		p->opvalue = "";
		p->extra = "";
	}

	mVarList.clear();
	mIsChangeVar = true;
}

TExpress::TExpress()
{ 
    mBHValue = 18;
    mDotNum = -1;
    mIsChangeVar = true;
}

TExpress::~TExpress()
{
	ClearVarList();
	ClearSblList();
}

string& replace_all_distinct(string& str, const string& old_value, const string& new_value);

string& StringReplace(string& str, const string& old_value, const string& new_value)
{
	string::size_type pos = 0;
	while ((pos = str.find(old_value, pos)) != string::npos)
	{
		str = str.replace(pos, old_value.length(), new_value);
		if (new_value.length() > 0)
		{
			pos += new_value.length();
		}
	}
	return str;
}
